(function() {
  var template = Handlebars.template, templates = Handlebars.templates = Handlebars.templates || {};
templates['post'] = template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    var helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=container.hooks.helperMissing, alias3="function", alias4=container.escapeExpression, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "<div class=\"post\" data-price="
    + alias4(((helper = (helper = lookupProperty(helpers,"price") || (depth0 != null ? lookupProperty(depth0,"price") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"price","hash":{},"data":data,"loc":{"start":{"line":1,"column":29},"end":{"line":1,"column":38}}}) : helper)))
    + " data-city="
    + alias4(((helper = (helper = lookupProperty(helpers,"city") || (depth0 != null ? lookupProperty(depth0,"city") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"city","hash":{},"data":data,"loc":{"start":{"line":1,"column":49},"end":{"line":1,"column":57}}}) : helper)))
    + " data-condition="
    + alias4(((helper = (helper = lookupProperty(helpers,"condition") || (depth0 != null ? lookupProperty(depth0,"condition") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"condition","hash":{},"data":data,"loc":{"start":{"line":1,"column":73},"end":{"line":1,"column":86}}}) : helper)))
    + ">\n  <div class=\"post-contents\">\n    <div class=\"post-image-container\">\n      <img src="
    + alias4(((helper = (helper = lookupProperty(helpers,"photoURL") || (depth0 != null ? lookupProperty(depth0,"photoURL") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"photoURL","hash":{},"data":data,"loc":{"start":{"line":4,"column":15},"end":{"line":4,"column":27}}}) : helper)))
    + " alt="
    + alias4(((helper = (helper = lookupProperty(helpers,"description") || (depth0 != null ? lookupProperty(depth0,"description") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"description","hash":{},"data":data,"loc":{"start":{"line":4,"column":32},"end":{"line":4,"column":47}}}) : helper)))
    + ">\n    </div>\n    <div class=\"post-info-container\">\n      <a href=\"#\" class=\"post-title\">"
    + alias4(((helper = (helper = lookupProperty(helpers,"description") || (depth0 != null ? lookupProperty(depth0,"description") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"description","hash":{},"data":data,"loc":{"start":{"line":7,"column":37},"end":{"line":7,"column":52}}}) : helper)))
    + "</a> <span class=\"post-price\">$"
    + alias4(((helper = (helper = lookupProperty(helpers,"price") || (depth0 != null ? lookupProperty(depth0,"price") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"price","hash":{},"data":data,"loc":{"start":{"line":7,"column":83},"end":{"line":7,"column":92}}}) : helper)))
    + "</span> <span class=\"post-city\">("
    + alias4(((helper = (helper = lookupProperty(helpers,"city") || (depth0 != null ? lookupProperty(depth0,"city") : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"city","hash":{},"data":data,"loc":{"start":{"line":7,"column":125},"end":{"line":7,"column":133}}}) : helper)))
    + ")</span>\n    </div>\n  </div>\n</div>\n\n";
},"useData":true});
templates['mainpage'] = template({"1":function(container,depth0,helpers,partials,data) {
    var stack1, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "    <section id=\"posts\">\n\n"
    + ((stack1 = container.invokePartial(lookupProperty(partials,"post"),(depth0 != null ? lookupProperty(depth0,"selectedPost") : depth0),{"name":"post","data":data,"indent":"      ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "\n    </section>\n\n";
},"3":function(container,depth0,helpers,partials,data) {
    var stack1, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "\n      <main class=\"content\">\n        <aside class=\"filter-container\">\n\n          <h2>Filters</h2>\n\n          <div class=\"filter-input-container\">\n            <label for=\"filter-text\" class=\"filter-input-label\">Text</label>\n            <div class=\"filter-input-element\">\n              <input type=\"text\" name=\"filter-text\" id=\"filter-text\" class=\"filter-input\">\n            </div>\n          </div>\n\n          <div class=\"filter-input-container\">\n            <label for=\"filter-min-price\" class=\"filter-input-label\">Price</label>\n            <div class=\"filter-input-element\">\n              <input type=\"text\" name=\"filter-min-price\" id=\"filter-min-price\" class=\"filter-input\" placeholder=\"min\">\n            </div>\n            <div class=\"filter-input-element\">\n              <input type=\"text\" name=\"filter-max-price\" id=\"filter-max-price\" class=\"filter-input\" placeholder=\"max\">\n            </div>\n          </div>\n\n          <div class=\"filter-input-container\">\n            <label for=\"filter-city\">City</label>\n            <div class=\"filter-input-element\">\n              <select id=\"filter-city\" class=\"filter-input\" name=\"filter-city\">\n                <option selected value=\"\">Any</option>\n                <option>Corvallis</option>\n                <option>Albany</option>\n                <option>Eugene</option>\n                <option>Portland</option>\n                <option>Salem</option>\n                <option>Bend</option>\n              </select>\n            </div>\n          </div>\n\n          <div class=\"filter-input-container\">\n            <fieldset id=\"filter-condition\" class=\"filter-fieldset\">\n              <legend>Condition</legend>\n              <div>\n                <input type=\"checkbox\" name=\"filter-condition\" id=\"filter-condition-new\" value=\"new\">\n                <label for=\"filter-condition-new\">New</label>\n              </div>\n              <div>\n                <input type=\"checkbox\" name=\"filter-condition\" id=\"filter-condition-excellent\" value=\"excellent\">\n                <label for=\"filter-condition-excellent\">Excellent</label>\n              </div>\n              <div>\n                <input type=\"checkbox\" name=\"filter-condition\" id=\"filter-condition-good\" value=\"good\">\n                <label for=\"filter-condition-good\">Good</label>\n              </div>\n              <div>\n                <input type=\"checkbox\" name=\"filter-condition\" id=\"filter-condition-fair\" value=\"fair\">\n                <label for=\"filter-condition-fair\">Fair</label>\n              </div>\n              <div>\n                <input type=\"checkbox\" name=\"filter-condition\" id=\"filter-condition-poor\" value=\"poor\">\n                <label for=\"filter-condition-poor\">Poor</label>\n              </div>\n            </fieldset>\n          </div>\n\n          <button id=\"filter-update-button\" class=\"action-button\">Update</button>\n\n        </aside>\n\n        <section id=\"posts\">\n\n"
    + ((stack1 = lookupProperty(helpers,"each").call(depth0 != null ? depth0 : (container.nullContext || {}),(depth0 != null ? lookupProperty(depth0,"postData") : depth0),{"name":"each","hash":{},"fn":container.program(4, data, 0),"inverse":container.noop,"data":data,"loc":{"start":{"line":84,"column":10},"end":{"line":86,"column":19}}})) != null ? stack1 : "")
    + "\n\n        </section>\n\n      </main>\n\n      <button type=\"button\" id=\"sell-something-button\"><i class=\"fas fa-plus\"></i></button>\n\n      <div id=\"modal-backdrop\" class=\"hidden\"></div>\n      <div id=\"sell-something-modal\" class=\"hidden\">\n        <div class=\"modal-dialog\">\n\n          <div class=\"modal-header\">\n            <h3>Sell something on Benny's List</h3>\n            <button type=\"button\" id=\"modal-close\" class=\"modal-hide-button\">&times;</button>\n          </div>\n\n          <div class=\"modal-body\">\n\n            <div class=\"post-input-element\">\n              <label for=\"post-text-input\">Item description</label>\n              <input type=\"text\" id=\"post-text-input\"></input>\n            </div>\n\n            <div class=\"post-input-element\">\n              <label for=\"post-photo-input\">Photo URL</label>\n              <input type=\"text\" id=\"post-photo-input\">\n            </div>\n\n            <div class=\"post-input-element\">\n              <label for=\"post-price-input\">Selling price ($)</label>\n              <input type=\"number\" id=\"post-price-input\">\n            </div>\n\n            <div class=\"post-input-element\">\n              <label for=\"post-city-input\">City</label>\n              <input type=\"text\" id=\"post-city-input\">\n            </div>\n\n            <div class=\"post-input-element\">\n              <fieldset id=\"post-condition-fieldset\" class=\"post-fieldset\">\n                <legend>Condition</legend>\n                <div>\n                  <input type=\"radio\" name=\"post-condition\" id=\"post-condition-new\" value=\"new\" checked>\n                  <label for=\"post-condition-new\">New</label>\n                </div>\n                <div>\n                  <input type=\"radio\" name=\"post-condition\" id=\"post-condition-excellent\" value=\"excellent\">\n                  <label for=\"post-condition-excellent\">Excellent</label>\n                </div>\n                <div>\n                  <input type=\"radio\" name=\"post-condition\" id=\"post-condition-good\" value=\"good\">\n                  <label for=\"post-condition-good\">Good</label>\n                </div>\n                <div>\n                  <input type=\"radio\" name=\"post-condition\" id=\"post-condition-fair\" value=\"fair\">\n                  <label for=\"post-condition-fair\">Fair</label>\n                </div>\n                <div>\n                  <input type=\"radio\" name=\"post-condition\" id=\"post-condition-poor\" value=\"poor\">\n                  <label for=\"post-condition-poor\">Poor</label>\n 		</div>\n              </fieldset>\n            </div>\n\n          </div>\n\n          <div class=\"modal-footer\">\n            <button type=\"button\" id=\"modal-cancel\" class=\"modal-hide-button action-button\">Cancel</button>\n            <button type=\"button\" id=\"modal-accept\" class=\"action-button\">Create Post</button>\n        </div>\n      </div>\n  </div>\n\n";
},"4":function(container,depth0,helpers,partials,data) {
    var stack1, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return ((stack1 = container.invokePartial(lookupProperty(partials,"post"),depth0,{"name":"post","data":data,"indent":"            ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "");
},"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1, lookupProperty = container.lookupProperty || function(parent, propertyName) {
        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {
          return parent[propertyName];
        }
        return undefined
    };

  return "<body>\n  <header>\n"
    + ((stack1 = container.invokePartial(lookupProperty(partials,"head"),depth0,{"name":"head","data":data,"indent":"    ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "  </header>\n\n"
    + ((stack1 = lookupProperty(helpers,"if").call(depth0 != null ? depth0 : (container.nullContext || {}),(depth0 != null ? lookupProperty(depth0,"displaySingle") : depth0),{"name":"if","hash":{},"fn":container.program(1, data, 0),"inverse":container.program(3, data, 0),"data":data,"loc":{"start":{"line":6,"column":2},"end":{"line":161,"column":9}}})) != null ? stack1 : "")
    + "\n</body>\n\n";
},"usePartial":true,"useData":true});
})();